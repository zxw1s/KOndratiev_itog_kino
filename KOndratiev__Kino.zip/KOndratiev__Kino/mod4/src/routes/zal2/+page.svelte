<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Зал №2</title>
    <style>
        /* Стили для страницы зала №2 */
        body {
            font-family: Arial, sans-serif;
        }
        h1 {
            text-align: center;
        }
        .seat-selection {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
    <script>
        // Скрипты для страницы зала №2
        // Возможно, здесь будут скрипты для выбора места и оплаты
    </script>
</head>
<body>
    <h1>Зал №2</h1>
    <div class="seat-selection">
        <label for="row">Выберите ряд:</label>
        <select name="row" id="row">
            <option value="1">Ряд 1</option>
            <option value="2">Ряд 2</option>
            <!-- Добавьте другие ряды по аналогии -->
        </select>
        <br>
        <label for="seat">Выберите место:</label>
        <select name="seat" id="seat">
            <option value="1">Место 1</option>
            <option value="2">Место 2</option>
            <!-- Добавьте другие места по аналогии -->
        </select>
        <br>
        <button onclick="pay()">Оплатить</button>
    </div>
    <a href="/sinema">Главная страница</a>
    <a href="/zal1">Зал №1</a>
</body>
</html>
